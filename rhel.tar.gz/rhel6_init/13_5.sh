#!/bin/bash

mkdir -p /var/log/sftp

filepath='/etc/ssh/sshd_config'

sed -i 's/\(Subsystem[[:space:]]*sftp[[:space:]]*internal-sftp\)$/\1 -f AUTHPRIV -l INFO/' $filepath

sed -i 's/\(ForceCommand[[:space:]]*internal-sftp\)$/\1 -f AUTHPRIV -l INFO/' $filepath

mkdir /sftp/sftpusr1/dev
mkdir /sftp/sftpusr2/dev
touch /sftp/sftpusr1/dev/log
touch /sftp/sftpusr2/dev/log

filepath='/etc/rsyslog.conf'
sed -i '/^authpriv/aauthpriv.info       /var/log/sftp/sftp.log' $filepath
cat >> $filepath <<EOF
AddUnixListenSocket /sftp/sftpusr1/dev/log
AddUnixListenSocket /sftp/sftpusr2/dev/log
EOF

cat >> /etc/logrotate.d/sftp <<EOF
/var/log/sftp/sftp.log {
    daily
    rotate 30
    compress
    copytruncate
    dateext
    dateformat -%Y%m%d
    sharedscripts
    postrotate
    /bin/kill -HUP `cat /var/run/syslogd.pid 2> /dev/null` 2> /dev/null || true
    Endscript
}
EOF

service sshd restart
service rsyslog restart

ls -l /sftp/sftpusr*/dev/log
