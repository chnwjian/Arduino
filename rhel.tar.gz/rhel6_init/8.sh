#!/bin/bash

cat >> /etc/yum.repos.d/rhel-souce.repo <<EOF
[rhel6]
name=Red Hat Enterprise Linux 6 BaseOS
baseurl=http://cmbyum.cmbchina.cn/rhel64/Server
enabled=1
gpgcheck=0
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
[rhel6_custom]
name=Red Hat Enterprise Linux 6 Custom
baseurl=http://cmbyum.cmbchina.cn/rhel64/Custom
enabled=1
gpgcheck=0
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
[rhel6_fix]
name=Red Hat Enterprise Linux 6 Fix
baseurl=http://cmbyum.cmbchina.cn/rhel64/fix
enabled=1
gpgcheck=0
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
EOF
yum repolist
