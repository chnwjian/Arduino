#!/bin/bash

[ $# -ne 1 ] && { echo "Usage: `basename $0` username";exit 1; }

usrhome="/ftp/$1"
usrname="$1"
useradd -s /sbin/nologin -d $usrhome "$usrname"
echo `id $usrname`
passwd $usrname

