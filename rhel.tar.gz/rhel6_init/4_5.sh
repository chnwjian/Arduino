#!/bin/bash

echo "export TMOUT=300" >> /etc/profile
echo "export HISTFILESIZE=5000" >> /etc/profile
sysfilepath='/etc/pam.d/system-auth-ac'
passfilepath='/etc/pam.d/password-auth-ac'
sed -i '/auth[[:space:]]*required[[:space:]]*pam_env.so/a\auth        required      pam_tally2.so onerr=fail deny=6 unlock_time=300 even_deny_root root_unlock_time=300' $sysfilepath
sed -i '/account[[:space:]]*required[[:space:]]*pam_unix.so/i\account     required      pam_tally2.so' $sysfilepath
sed -i '/auth[[:space:]]*required[[:space:]]*pam_env.so/a\auth        required      pam_tally2.so onerr=fail deny=6 unlock_time=300 even_deny_root root_unlock_time=300' $passfilepath
sed -i '/account[[:space:]]*required[[:space:]]*pam_unix.so/i\account     required      pam_tally2.so' $passfilepath

