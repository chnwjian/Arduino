#!/bin/bash

echo "LOG_UNKFAIL_ENAB      yes" >> /etc/login.defs
echo "LOGIN_RETRIES         6" >> /etc/login.defs
echo "LASTLOG_ENAB          yes" >> /etc/login.defs
