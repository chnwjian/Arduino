#!/bin/bash

filepath='/etc/ssh/sshd_config'

sed -i 's/^#Port 22/Port 22/g' $filepath
sed -i 's/^#LogLevel INFO/LogLevel INFO/g' $filepath
sed -i 's/^#MaxAuthTries 6/MaxAuthTries 3/g' $filepath
sed -i 's/^#PasswordAuthentication yes/PasswordAuthentication yes/g' $filepath
sed -i 's/^#RhostsRSAAuthentication no/RhostsRSAAuthentication no/g' $filepath
sed -i 's/^#PermitEmptyPasswords no/PermitEmptyPasswords no/g' $filepath
sed -i 's/^#StrictModes yes/StrictModes yes/g' $filepath
sed -i 's/^#IgnoreUserKnownHosts no/IgnoreUserKnownHosts yes/g' $filepath
sed -i 's/^\(Protocol \).*/\12/g' $filepath
cat >> /etc/ssh/sshd_config <<< "Ciphers 3des-cbc"
cat >> /etc/ssh/sshd_config <<< "MACs hmac-sha1,hmac-md5"
