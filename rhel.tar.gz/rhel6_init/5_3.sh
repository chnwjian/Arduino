#!/bin/bash

filepath='/etc/sysctl.conf'
sed -i 's/^\(net.ipv4.conf.all.arp_ignore = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.default.arp_ignore = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.arp_filter = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.default.arp_filter = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.rp_filter = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.log_martians = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.default.log_martians = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.promote_secondaries = \).*/\11/g' $filepath
sed -i 's/^\(net.ipv4.ip_no_pmtu_disc = \).*/\11/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.forwarding = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.default.forwarding = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.icmp_echo_ignore_broadcasts = \).*/\11/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.accept_source_route = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.default.accept_source_route = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.accept_redirects = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.default.accept_redirects = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.secure_redirects = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.tcp_timestamps = \).*/\11/g' $filepath
sed -i 's/^\(net.ipv4.icmp_ignore_bogus_error_responses = \).*/\11/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.proxy_arp = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.default.proxy_arp =  \).*/\10/g' $filepath
sed -i 's/^\(net.core.somaxconn = \).*/\11024/g' $filepath
sed -i 's/^\(net.ipv4.tcp_max_syn_backlog = \).*/\18192/g' $filepath
sed -i 's/^\(net.ipv4.tcp_syncookies = \).*/\11/g' $filepath
sed -i 's/^\(net.ipv4.tcp_fin_timeout = \).*/\160/g' $filepath
sed -i 's/^\(net.ipv4.ip_forward = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.conf.all.send_redirects = \).*/\10/g' $filepath
sed -i 's/^\(net.ipv4.tcp_keepalive_time = \).*/\1150/g' $filepath
sed -i 's/^\(net.ipv4.tcp_keepalive_probes = \).*/\15/g' $filepath
sed -i 's/^\(net.ipv4.tcp_keepalive_intvl = \).*/\16/g' $filepath
sysctl -p
