#!/bin/bash

cat >> test <<EOF
DEVICE=eth0
ONBOOT=yes
BOOTPROTO=none
TYPE=Ethernet
NM_CONTROLLED=no
MASTER=bond0
SLAVE=yes
EOF

echo "alias bond0 bonding"  >> /etc/modprobe.d/bonding.conf

echo "any net 10.0.18.0/24 gw 10.0.18.253" >> /etc/sysconfig/static-routes
service network restart
route -n | grep UG
