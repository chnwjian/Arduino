#!/bin/bash

[ -d /sftp/sftpusr1 ] || mkdir -p /sftp/sftpusr1
[ -d /sftp/sftpusr2 ] || mkdir -p /sftp/sftpusr2

chown root /sftp/sftpusr1
chown root /sftp/sftpusr2
chmod 755 /sftp/sftpusr1
chmod 755 /sftp/sftpusr2


mkdir /sftp/sftpusr1/data1
chown sftpusr1:sftpgrp /sftp/sftpusr1/data1

mkdir /sftp/sftpusr2/data2
chown sftpusr2:sftpgrp /sftp/sftpusr2/data2
