#!/bin/bash

filepath='/etc/vsftpd/vsftpd.conf'

sed -i 's/^\(anonymous_enable=\).*/\1NO/' $filepath
sed -i 's/^\(local_enable=\).*/\1YES/' $filepath
sed -i 's/^\(write_enable=\).*/\1YES/' $filepath
sed -i 's/^\(local_umask=\).*/\1022/' $filepath

sed -i 's/^#chroot_local_user=YES/chroot_local_user=YES/' $filepath
sed -i 's/^#chroot_list_enable=YES/chroot_list_enable=YES/' $filepath
sed -i 's@^#chroot_list_file=/etc/vsftpd/chroot_list@chroot_list_file=/etc/vsftpd/chroot_list@' $filepath

touch /etc/vsftpd/chroot_list
chmod 600 /etc/vsftpd/chroot_list

sed -i 's/^\(userlist_enable=\).*/\1YES/' $filepath
echo "userlist_deny=NO" >> $filepath

echo ftpusr1 >> /etc/vsftpd/user_list
echo ftpusr2 >> /etc/vsftpd/user_list

sed -i 's/^\(tcp_wrappers=\).*/\1YES/' $filepath

cat >> /etc/hosts.allow <<< "vsftpd: 10.1.2.3,10.2.3.4"
cat >> /etc/hosts.deny <<< "vsftpd: ALL"

cat >> $filepath <<EOF
user_sub_token=$USER
local_root=/ftp/$USER
EOF

cat >> $filepath <<< "dual_log_enable=YES"
cat >> $filepath <<EOF
user_config_dir=/etc/vsftpd/user_conf
EOF

mkdir -p /etc/vsftpd/user_conf
echo "max_clients=30" > /etc/vsftpd/user_conf/ftpusr1
chown root:root /etc/vsftpd/user_conf/ftpusr1

echo "idle_session_timeout=300" >> $filepath
