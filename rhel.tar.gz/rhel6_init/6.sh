#!/bin/bash

cat >> /etc/sudoers <<EOF
#创建alias PRIVUSERS 然后添加 sudo 用户oracle，这样可以使多个用户有相同的权限
User_Alias PRIVUSERS = oracle
#创建 alias PRIVSERVICES 这样便于以后可以添加多个命令
Cmnd_Alias PRIVSERVICES = /sbin/fdisk
#指定之前创建的alias给指定的用户/用户组
PRIVUSERS ALL=(ALL) PRIVSERVICES
EOF
