#!/bin/bash

cat >> /etc/hosts.deny <<< "SSHD: ALL"
cat >> /etc/hosts.allow <<< "SSHD: 10.0. 10.1. 10.2. 10.3."
