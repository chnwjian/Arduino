#!/bin/bash

rm /root/.rhosts /root/.shosts /etc/hosts.equiv /etc/shosts.equiv
