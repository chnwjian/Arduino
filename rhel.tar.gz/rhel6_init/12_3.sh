#!/bin/bash

#start service
service vsftpd start

#service status
service vsftpd status

#开机自启
chkconfig vsftpd on
