#!/bin/bash

filepath='/etc/ssh/sshd_config'

sed -i 's@^\(Subsystem[[:space:]]*sftp[[:space:]]*/usr/libexec/openssh/sftp-server\)@#\1@' $filepath

cat >> $filepath <<< "Subsystem     sftp    internal-sftp"

sed -i '/#Match User anoncvs/i \
ClientAliveCountMax 0 \
ClientAliveInterval 300' $filepath

cat >> $filepath <<EOF
Match Group sftpgrp
        ForceCommand internal-sftp
        AllowTcpForwarding no
        X11Forwarding no
        ChrootDirectory /sftp/%u
EOF
service sshd restart
