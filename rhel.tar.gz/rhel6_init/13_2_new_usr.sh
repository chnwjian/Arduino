#!/bin/bash

[ $# -ne 1 ] && { echo "Usage: `basename $0` usrname."; exit 1; }

usrname=$1
groupadd sftpgrp
useradd -s /sbin/nologin -G sftpgrp $usrname
id $usrname
passwd $usrname
